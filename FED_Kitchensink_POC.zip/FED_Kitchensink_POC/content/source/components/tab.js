// function openCity(evt, cityName) {
//   var i, tabcontent, tablinks;
//   tabcontent = document.getElementsByClassName("tabcontent");
//   for (i = 0; i < tabcontent.length; i++) {
//     tabcontent[i].style.display = "none";
//   }
//   tablinks = document.getElementsByClassName("tablinks");
//   for (i = 0; i < tablinks.length; i++) {
//     tablinks[i].className = tablinks[i].className.replace(" active", "");
//   }
//   document.getElementById(cityName).style.display = "block";
//   evt.currentTarget.className += " active";
// }

// // Get the element with id="defaultOpen" and click on it
// document.getElementById("defaultOpen").click();


  $('#blogCarousel').carousel({
    interval: 5000
});


$(document).ready(function() {
var listlength=3;
var listID=1;
$('.carousel-inner  span').html("0"+listID+"/"+ "0"+listlength);
$('#myTabContent ul').slick({
  infinite: true,
  slidesToShow: 3,
  slidesToScroll: 1,
  arrows: true,
  vertical: true
}); 
});



$('.carousel-indicators li').click (function() {
   listlength= $( '.carousel-indicators li' ).length;
   listID=Number($(this).attr('data-slide-to'))+1;
   $('.carousel-inner  span').html("0"+listID+"/"+ "0"+listlength)
  
});


