﻿module.exports = function (grunt) {
    grunt.loadTasks('grunt');
};