﻿module.exports = function (grunt) {

	grunt.registerTask('vendor', 'Combine vendor files', function () {

		grunt.config('concat', {
			options: {
				separator: ';\n\n',
				banner: '/*! vendor libs <%= grunt.template.today("yyyy-mm-dd HH:MM:ss") %> */\n'
			},
			css: {
                src: ['content/vendor/bootstrap/css/bootstrap.min.css'],
				dest: 'content/target/styles/vendor.min.css'
			},
			js: {
                src: ['content/vendor/jquery/js/jquery.min.js',
                    './node_modules/bootstrap/dist/js/bootstrap.bundle.min.js',
                    './node_modules/vue/dist/vue.min.js',
                    './node_modules/axios/dist/axios.js',
					'./node_modules/vuex/dist/vuex.js',
					'./node_modules/vue-scrollto/vue-scrollto.js',
                    './node_modules/vue-observe-visibility/dist/vue-observe-visibility.min.js',
                    './node_modules/intersection-observer/intersection-observer.js',
                    './node_modules/vuejs-datepicker/dist/vuejs-datepicker.min.js'],
				dest: 'content/target/scripts/vendor.min.js'
			}
        });

        grunt.loadNpmTasks('grunt-contrib-concat');
        grunt.task.run('concat');
	});
};