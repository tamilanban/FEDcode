﻿module.exports = function (grunt) {

	grunt.registerTask('main-css', 'Compile core CSS', function () {

		grunt.config('pkg', grunt.file.readJSON('package.json'));

		grunt.config('sass', {
            build: {
                options: {
                    map: false,
                    sourcemap: 'none'
                },
                files: {					
					'content/target/styles/main.css': 'content/source/main.scss'
                }
            }
		});
		grunt.config('cssmin', {
			dist: {
				files: {			
					'content/target/styles/main.min.css': 'content/target/styles/main.css',
				}
			}
		});

		grunt.loadNpmTasks('grunt-contrib-sass');
		grunt.loadNpmTasks('grunt-contrib-cssmin');
		grunt.task.run('sass');
		grunt.task.run('cssmin');
    });   

	grunt.registerTask('main-js', 'Compile core JS', function () {

        grunt.config('pkg', grunt.file.readJSON('package.json'));

        grunt.config('eslint', {
            options: {
                quiet: true
            },
            target: ['content/source/modules-app/**/*.js']
        });

		grunt.config('concat', {
			options: {
                separator: '\n\n',
                sourceMap: false,
				banner: '/*! <%= grunt.template.today("yyyy-mm-dd HH:MM:ss") %> */\n'
			},
            dist: {                
                src: ['content/source/modules-app/api/**/*.js',
                      'content/source/modules-app/module/**/*.js', 
                      'content/source/modules-app/store/**/*.js', 
                      'content/source/modules-app/components/**/*.js', 
                      'content/source/modules-app/apps/**/*.js'],
                dest: 'content/target/scripts/main.js'
			}
        });

        grunt.config('browserify', {
            development: {
                src: [
                    'content/target/scripts/main.js'
                ],
                dest: 'content/target/scripts/main-compiled.js',
                options: {
                    browserifyOptions: { debug: true },
                    transform: [["babelify", { "presets": ["@babel/preset-env"] }]]
                }
            },
            production: {
                src: [
                    'content/target/scripts/main.js'
                ],
                dest: 'content/target/scripts/main-compiled.js',
                options: {
                    browserifyOptions: { debug: false },
                    transform: [["babelify", { "presets": ["@babel/preset-env"] }]],
                    plugin: [
                        ["minifyify", { map: false }]
                    ]
                }
            }
        });

		grunt.config('uglify', {
			options: {
                banner: '/*! <%= grunt.template.today("yyyy-mm-dd HH:MM:ss") %> */\n',
			},
			dist: {			
				src: 'content/target/scripts/main-compiled.js',
				dest: 'content/target/scripts/main.min.js'
			}
		});

        grunt.loadNpmTasks('grunt-contrib-concat');
        grunt.loadNpmTasks('grunt-browserify');
        grunt.loadNpmTasks('grunt-contrib-uglify-es');
        grunt.loadNpmTasks('grunt-eslint');

        grunt.task.run('eslint');
        grunt.task.run('concat');
        grunt.task.run('browserify:development');
		grunt.task.run('uglify');

    });
};