﻿module.exports = function (grunt) {
	grunt.registerTask('monitor-files', 'Watch all files', function () {
		grunt.config('clean', {
			build: {
				src:'content/target/**/*.*'				
			}					
		});
		grunt.config('watch', {
			coreJS: {
                files: 'content/source/**/*.js',
				tasks: ['main-js']
			},
			coreCSS: {
                files: 'content/source/**/*.scss',
                tasks: ['main-css']
			}
		});
		grunt.loadNpmTasks('grunt-contrib-clean');
		grunt.loadNpmTasks('grunt-contrib-watch');
		grunt.task.run('clean');
		grunt.task.run('watch');
	});
};