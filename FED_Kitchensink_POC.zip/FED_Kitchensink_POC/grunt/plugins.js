﻿module.exports = function (grunt) {


	grunt.registerTask('eslint-validation', 'Minify plugins', function () {
		grunt.config('eslint', {
			options: {
				quiet: true
			},
			target: ['content/source/modules-app/**/*.js', 'content/source/modules-app/**/**/*.js']
		});

		grunt.loadNpmTasks('grunt-eslint');
		grunt.task.run('eslint');

	});





};